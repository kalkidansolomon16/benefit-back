<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'telegram' => [
        'bot_token'    => env('TELEGRAM_BOT_TOKEN', ''),
        'bot_username' => env('TELEGRAM_BOT_USERNAME', 'FitAccessBot'),
        'proxy'        => env('TELEGRAM_PROXY', ''),
    ],

    'chapa' => [
        'secret_key'     => env('CHAPA_SECRET_KEY'),
        'public_key'     => env('CHAPA_PUBLIC_KEY'),
        'base_url'       => 'https://api.chapa.co/v1',
        'return_url'     => env('CHAPA_RETURN_URL', 'http://localhost:5173/hr/billing/chapa-return'),
        'webhook_url'    => env('CHAPA_WEBHOOK_URL', env('APP_URL') . '/api/v1/chapa/webhook'),
        // Set in the Chapa dashboard's Webhooks tab (Settings → Webhooks) when you
        // register the webhook URL — distinct from the API secret key.
        'webhook_secret' => env('CHAPA_WEBHOOK_SECRET'),
    ],

    'recaptcha' => [
        'site_key'   => env('RECAPTCHA_SITE_KEY'),
        'secret_key' => env('RECAPTCHA_SECRET_KEY'),
        'min_score'  => env('RECAPTCHA_MIN_SCORE', 0.5),
    ],

];
