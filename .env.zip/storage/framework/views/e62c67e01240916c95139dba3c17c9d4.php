<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($emailSubject); ?></title>
</head>
<body style="margin:0;padding:0;background:#f2f2f2;font-family:Arial,Helvetica,sans-serif;color:#0B0C10;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f2f2f2;padding:32px 12px;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:20px;overflow:hidden;">

        <!-- Header -->
        <tr>
          <td style="padding:28px 40px;border-bottom:1px solid #ececec;">
            <span style="display:inline-block;width:14px;height:14px;border-radius:50%;background:#8BE000;vertical-align:middle;"></span>
            <span style="font-size:22px;font-weight:800;color:#0B0C10;vertical-align:middle;margin-left:6px;">FitAccess</span>
          </td>
        </tr>

        <!-- Body -->
        <tr>
          <td style="padding:36px 40px 12px;">
            <?php if($highlight): ?>
              <p style="margin:0 0 18px;font-size:19px;font-weight:700;line-height:1.4;color:#0B0C10;"><?php echo e($highlight); ?></p>
            <?php endif; ?>

            <h1 style="margin:0 0 18px;font-size:30px;line-height:1.2;font-weight:700;color:#0B0C10;"><?php echo e($heading); ?></h1>

            <?php if($recipientName): ?>
              <p style="margin:0 0 14px;font-size:15px;line-height:1.7;">Dear <strong><?php echo e($recipientName); ?></strong>,</p>
            <?php endif; ?>

            <?php $__currentLoopData = $paragraphs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <p style="margin:0 0 14px;font-size:15px;line-height:1.7;"><?php echo nl2br(e($p)); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(!empty($details)): ?>
              <table cellpadding="0" cellspacing="0" width="100%" style="margin:10px 0 22px;border:1px solid #ececec;border-radius:12px;">
                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td style="padding:10px 16px;font-size:14px;color:#555;width:42%;border-bottom:1px solid #f2f2f2;"><?php echo e($label); ?></td>
                    <td style="padding:10px 16px;font-size:14px;font-weight:600;border-bottom:1px solid #f2f2f2;"><?php echo e($value); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            <?php endif; ?>

            <?php if(!empty($credentials)): ?>
              <table cellpadding="0" cellspacing="0" width="100%" style="margin:10px 0 22px;background:#0B0C10;border-radius:14px;">
                <?php $__currentLoopData = $credentials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td style="padding:12px 20px 4px;font-size:12px;color:#8BE000;text-transform:uppercase;letter-spacing:1px;"><?php echo e($label); ?></td>
                  </tr>
                  <tr>
                    <td style="padding:0 20px 12px;font-size:18px;font-weight:700;color:#ffffff;font-family:Consolas,Menlo,monospace;"><?php echo e($value); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            <?php endif; ?>

            <?php if(!empty($steps)): ?>
              <p style="margin:18px 0 10px;font-size:16px;font-weight:700;">What now?</p>
              <table cellpadding="0" cellspacing="0" width="100%" style="margin:0 0 18px;">
                <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td valign="top" style="padding:6px 0;width:92px;font-size:15px;font-weight:700;white-space:nowrap;">
                      <span style="color:#72B800;">&#10004;</span> Step <?php echo e($i + 1); ?>:
                    </td>
                    <td valign="top" style="padding:6px 0;font-size:15px;line-height:1.6;"><?php echo e($step); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            <?php endif; ?>

            <?php if($buttonText && $buttonUrl): ?>
              <table cellpadding="0" cellspacing="0" style="margin:8px 0 24px;">
                <tr>
                  <td style="background:#8BE000;border-radius:999px;padding:14px 30px;">
                    <a href="<?php echo e($buttonUrl); ?>" style="color:#0B0C10;font-size:15px;font-weight:700;text-decoration:none;"><?php echo e($buttonText); ?></a>
                  </td>
                </tr>
              </table>
            <?php endif; ?>

            <?php if($closing): ?>
              <p style="margin:0 0 6px;font-size:15px;line-height:1.7;"><?php echo e($closing); ?></p>
            <?php endif; ?>
            <p style="margin:16px 0 28px;font-size:15px;line-height:1.7;">Best regards,<br>FitAccess Team</p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#0B0C10;padding:22px 40px;">
            <p style="margin:0;font-size:12px;line-height:1.6;color:#cfcfcf;">
              FitAccess — the employee wellness benefit for Addis Ababa.<br>
              If you have any questions, simply reply to this email.
            </p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\benefit\benefit-back\resources\views/emails/fitaccess-branded.blade.php ENDPATH**/ ?>